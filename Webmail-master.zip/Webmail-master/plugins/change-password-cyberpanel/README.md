RainLoop CyberPanel Password Changing Plugin
============================================

This plugin adds password changing capability to RainLoop webmail for servers running CyberPanel web panel software.

##### Installation is simple:

1. Place the change-password-cyberpanel folder in the plugins directory (e.g. _RainLoopDir_/data/data_xxxxx/_default/plugins/*).
2. In RainLoop administration panel, go to Plugins and activate change-password-cyberpanel.
3. Enter CyberPanel's SQL user details on the plugin configuration screen.
