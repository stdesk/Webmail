import bootstrap from 'bootstrap';
import App from 'App/User';

bootstrap(App);
