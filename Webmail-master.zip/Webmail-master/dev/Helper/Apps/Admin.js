/**
 * @returns {AppAdmin}
 */
export function getApp() {
	return require('App/Admin').default;
}
