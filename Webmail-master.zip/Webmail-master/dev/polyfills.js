import 'core-js/features/object/assign';
import 'core-js/features/array/includes';
import 'core-js/features/string/includes';
import 'core-js/features/promise';
import 'raf/polyfill';
